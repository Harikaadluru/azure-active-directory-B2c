﻿/// <reference path="jquery-3.7.1.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
